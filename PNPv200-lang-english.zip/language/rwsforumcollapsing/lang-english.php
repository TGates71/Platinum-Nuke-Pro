<?php
/*********************************************************/
/* Raven's Collapsing Forums Block                       */
/* By: RavenWebServices (tm) (raven@ravenphpscripts.com) */
/* http://ravenphpscripts.com http://ravenwebhosting.com */
/* Copyright � 2005 by RavenWebServices                  */
/*********************************************************/
/*********************************************************/
/*              Collapsing Forums Block                  */
/*********************************************************/
define('bfcTOPICLOCKED','Topic Locked');
define('bfcBACKENDTITLE','Syndicate Platinum Nuke Pro v100');
define('bfcTOPPOSTERS','Top Posters:');
define('bfcMYSQLSAID','MySQL said: ');
define('bfcJUMPFORUM','Jump To Forum');
define('bfcJUMPFUNCTION','Jump To Function');
define('bfcGETCATEGORYLISTERROR','Couldn\'t obtain category list. ');
define('bfcGETFORUMINFOERROR','Couldn\'t obtain forums information. ');
define('bfcSELECT','Select');
define('bfcVIEWPOSTSSINCELASTVISIT','View Posts Since Last Visit');
define('bfcVIEWYOURPOSTS','View Your Posts');
define('bfcVIEWUNANSWEREDPOSTS','View Unanswered Posts');
define('bfcFORUMINDEX','Forum Index');
define('bfcSEARCHFORUMS','Search Forums');
define('bfcWATCHEDTOPICS','View/Edit Your Watched Posts');
define('bfcPROFILE','Profile');
define('bfcPRIVATEMESSAGES','Private Messages');
define('bfcFORUM','Forum');
define('bfcTOPIC','Topic');
define('bfcREPLIES','Replies');
define('bfcAUTHOR','Author');
define('bfcVIEWS','Views');
define('bfcLASTPOST','Last Post');
define('bfcSHOWHIDE','Show/Hide');
define('bfcSHOWHIDELABELTEXT','Click on the Show/Hide text (on the far right) to expand/collapse this block');
?>