<?php
/********************************************************/
/* Site Credits Module for PHP-Nuke                     */
/* Version 1.0.1         4-03-04                        */
/* By: Telli (telli@codezwiz.com)                       */
/* http://codezwiz.com/                                 */
/* Copyright � 2000-2004 by Codezwiz                    */
/********************************************************/

define("_ADMINLINK","[ <a href='admin.php?op=credits'>Site Credits Admin Area</a> ]");
define("_CREDITS","Site Credits");
define("_MOD_NAME","<strong>Module (add-on)</strong>");
define("_MOD_DESCRIPTION","<strong>Module Description</strong>");
define("_MOD_AUTHOR","<strong>Author(s)</strong>");
define("_MOD_LINK","<strong>Authors Link</strong>");

?>