<?php

/*****************************************************/
/* English Language file                             */
/* From Module : What's New                              */
/* Translation by : Jonathan Estrella              */
/* Email : kiedis.axl@gmail.com                      */
/* URL : http://metalrebelde.net.tc          */
/*****************************************************/

/*****************************************************/
/* From file : modules/Whats_New/index.php          */
/*****************************************************/

define("_LDOWNLOADS","Downloads");
define("_LHITS","Hits");
define("_CATEGORY","Category");
define("_LATESTSTORIES","Latest Headlines");
define("_LATESTREVIEWS","Latest Reviews");
define("_LATESTDOWNLOADS","Latest Downloads");
define("_LATESTPAGES","Latest Content Pages");
define("_LATESTLINKS","Latest Web Links");
define("_LATESTUSERS","Latest Registered Users");
define("_POINTS","Points");
define("_LATESTBANDS","Latest Added Bands");
define("_TMGENRE","Genre");
define("_NEWS","News");
define("_REVIEWS","Reviews");
define("_CONTENT","Content");
define("_DOWNLOADS","Downloads");
define("_WEBLINKS","Links");
define("_TOPMUSIC","Artists");
define("_USERS","Users");
define("_BACK2TOP","Back to Top");

?>