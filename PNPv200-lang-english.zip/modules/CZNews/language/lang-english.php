<?php
/*
  Evolution Engine: Advanced Content Management System
  Copyright (c) 2002-2005 Codezwiz Network, LLC.
  ****************************************************
  A highly modified version of PHP-Nuke 6.5 which is 
  Copyright (c) 2002 by Francisco Burzi
  http://phpnuke.org

  Under the GNU General Public License version 2
*/

define("_CZNEWSSTORIES","News Stories");
define("_CZNEWS","News");
define("_CZPAGE","Page");
define("_CZCOMMENTS","Comments");
define("_CZVOTES","Votes");
define("_CZSCORE","Score");
define("_CZSUBMITTEDBY","Submitted by");
define("_CZREADS","reads");
define("_CZSUBMITNEWS","Submit News");
define("_CZALLNEWS","All News");

?>