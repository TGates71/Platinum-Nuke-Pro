<?php

/********************************************************/
/* NSN Groups                                           */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2005 by NukeScripts Network         */
/********************************************************/

//define('_GR_','');
define('_GR_MUSTBEUSER','You <strong>MUST BE</strong> logged in to join a group');
//define('_GR_GRPNAME','Group Name');
//define('_GR_NUMUSERS','# Users');
//define('_GR_NOLIMIT','No Limit');
//define('_GR_LIMIT','Limit');
//define('_GR_DESCRIPTION','Description');
define('_GR_GROUPINFO','Group Information');
define('_GR_GROUPJOIN','Join Group');
define('_GR_PUBLICGROUPS','Public Groups');
define('_GR_NOPUBLICGROUP','There is no public group with this id.');
define('_GR_NOPUBLICGROUPS','There are no public groups in the database.');
define('_GR_FILLED','Filled');
//define('_GR_INGROUP','You are already in this group.');
define('_GR_ADDGROUP','You have been added to the group.');
define('_GR_GROUPFILLED','This group has reached it member limit.');
define('_GR_JOIN','Join');
define('_GR_INFO','Info');
define('_GR_NOTPUBLIC','This is not a public group.');

?>