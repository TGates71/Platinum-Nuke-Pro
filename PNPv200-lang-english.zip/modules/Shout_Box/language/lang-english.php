<?php
// ==========================================
// PHP-NUKE: Shout Box
// ==========================
//
// Copyright (c) 2004 by Aric Bolf (SuperCat)
// http://www.OurScripts.net
//
// This program is free software. You can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation
// ===========================================

define("_SHOUTHISTORY","Shout History");
define("_SEARCHRESULTS","Search results");
define("_EDIT","Edit");
define("_DELETE","Delete");
define("_NORESULTS","No results!");
define("_SEARCHBOX","Search Box");
define("_SHOUTS","Shouts");
define("_SBNICKNAMES","Nicknames");
define("_SBBOTH","Both");
define("_EXACTPHRASE","Exact phrase");
define("_FUZZY","Fuzzy");
define("_SBRESULTS","Results");
define("_ANYTIME","anytime");
define("_PAST3MO","past 3 months");
define("_PAST6MO","past 6 months");
define("_PASTYEAR","past year");
define("_NEWESTFIRST","Newest first");
define("_OLDESTFIRST","Oldest first");
define("_SBSEARCH","Search");
define("_SHOUTBOXEDIT","Shout Box editor");
define("_SB_NOTE","Note");
define("_UPDATE","Update");
define("_SHOUTBOXHISTORY","Shout Box History");
define("_EDITINGOTHERSDISALLOWED","You are not allowed to edit other user\'s shouts.");
define("_EDITINGDISABLEDBYADMIN","Editing and deleting shouts has been disabled by Admininstration.");
define("_SHOUTTOOSHORT","Shout too short.");
define("_SHOUTTOOLONG","Shout too long.");
define("_NOSHOUT","No shout.");
define("_SB_MESSAGE","Message");
define("_XXXBLOCKED",".XXX URLs blocked");
define("_JSINSHOUT","JavaScript in shout.");
define("_URLNOTALLOWED","URLs not allowed in shouts.");
define("_PREVIOUS","Previous");
define("_PAGE","Page");
define("_NEXT","Next");
define("_YOUAREBANNEDM","You are BANNED!");

?>