<?php

/************************************************************************/
/* Contact Plus V2.2b for Nuke 6.5 - 7.2                                */
/* Copyright (c) 2004 by Shawn Archer                                   */
/* http://www.NukeStyles.com                                            */
/************************************************************************/
/* Platinum Nuke Pro: Expect to be impressed                  COPYRIGHT */
/*                                                                      */
/* Copyright (c) 2004 - 2006 by http://www.techgfx.com                  */
/*     Techgfx - Graeme Allan                       (goose@techgfx.com) */
/*                                                                      */
/* Copyright (c) 2004 - 2006 by http://www.nukeplanet.com               */
/*     Loki / Teknerd - Scott Partee           (loki@nukeplanet.com)    */
/*                                                                      */
/* Copyright (c) 2007 - 2013 by http://www.platinumnukepro.com          */
/*                                                                      */
/* Refer to platinumnukepro.com for detailed information on this CMS    */
/*******************************************************************************/
/* This file is part of the PlatinumNukePro CMS - http://platinumnukepro.com   */
/*                                                                             */
/* This program is free software; you can redistribute it and/or               */
/* modify it under the terms of the GNU General Public License                 */
/* as published by the Free Software Foundation; either version 2              */
/* of the License, or any later version.                                       */
/*                                                                             */
/* This program is distributed in the hope that it will be useful,             */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of              */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               */
/* GNU General Public License for more details.                                */
/*                                                                             */
/* You should have received a copy of the GNU General Public License           */
/* along with this program; if not, write to the Free Software                 */
/* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
/*******************************************************************************/
/************************************************************************/
/* Platinum Nuke Pro: Expect to be impressed                  COPYRIGHT */
/*                                                                      */
/* Copyright (c) 2004 - 2006 by http://www.techgfx.com                  */
/*     Techgfx - Graeme Allan                       (goose@techgfx.com) */
/*                                                                      */
/* Copyright (c) 2004 - 2006 by http://www.nukeplanet.com               */
/*     Loki / Teknerd - Scott Partee           (loki@nukeplanet.com)    */
/*                                                                      */
/* Copyright (c) 2007 - 2013 by http://www.platinumnukepro.com          */
/*                                                                      */
/* Refer to platinumnukepro.com for detailed information on this CMS    */
/*******************************************************************************/
/* This file is part of the PlatinumNukePro CMS - http://platinumnukepro.com   */
/*                                                                             */
/* This program is free software; you can redistribute it and/or               */
/* modify it under the terms of the GNU General Public License                 */
/* as published by the Free Software Foundation; either version 2              */
/* of the License, or any later version.                                       */
/*                                                                             */
/* This program is distributed in the hope that it will be useful,             */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of              */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               */
/* GNU General Public License for more details.                                */
/*                                                                             */
/* You should have received a copy of the GNU General Public License           */
/* along with this program; if not, write to the Free Software                 */
/* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
/*******************************************************************************/

define("_CON_ADM_LNK","Contact Us");

define("_CONTACTUS","Contact Us");
define("_THANKYOUFOR","Thank you for Contacting");
define("_ERROR2","There was an error sending your email.");
define("_TRYAGAIN","We are sorry, please try again later.");
define("_ERROR","<font color=\"#CC0000\">The email address you entered is invalid!</font>");
define("_GETBACK","We will get back with you as soon as possible.");
define("_EMAILSENT","Your email message was sent successfully.");
define("_BACK","Go Back");
define("_FORMHEADER","Use this form to Contact<br>any Department at");
define("_INVALIDEMAIL","The email address");
define("_INVALIDEMAIL2","is invalid.");
define("_NOMESSAGE","You didn't write a message!");
define("_PLEASEGO","Please <a href=\"javascript:history.go(-1)\">Go Back</a> and enter a valid email address.");
define("_PLEASEGO2","Please <a href=\"javascript:history.go(-1)\">Go Back</a> and enter a message.");
define("_PLEASEGO3","Please <a href=\"javascript:history.go(-1)\">Go Back</a> and select a Department.");
define("_YOURNAME","Your Name");
define("_OPTIONAL","Optional");
define("_YOUREMAIL","Your Email");
define("_YOURMESSAGE","Your Message");
define("_PLEASESELECT","Select Department");
define("_SEND","Send");
define("_CLEAR","Clear");
define("_MAILINGINFO","Mailing Information");
define("_PHONEANDFAX","Phone & Fax Information");
define("_DEPARTMENT","Department");
define("_TODEPARTMENT","To Department");
define("_SELECTDEPARTMENT","You did not select a Contact Department.");
define("_CONTACTFORM","Contact Form");
define("_FROM","From");
define("_VISITOR","From Visitor");
define("_MESSAGE","Message");
define("_CONTACTMESSSENT","Contace Message Sent");
define("_ADDRESSINFO","Address Information");
define("_PHONEINFO","Available Contact Numbers");
define("_NSPHONENAME","Phone Name");
define("_NSPHONENUM","Phone Number");
define("_NSFAXNUM","Fax Number");

?>

