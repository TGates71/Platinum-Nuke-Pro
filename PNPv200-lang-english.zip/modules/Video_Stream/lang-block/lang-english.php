<?php
define("_BRATING","Rating");
define("_BTVOTES","Votes");
define("_BBY","By");
define("_BBON","On");
define("_BVIEWS","Views");
?>